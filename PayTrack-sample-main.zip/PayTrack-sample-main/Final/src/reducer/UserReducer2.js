export const initial = "";

export const reducer2 = (state, action) => {
    // if(action.type == 'Loggedin')
    // {
    //     //return state;
    //     return action.payload;
    // }
    return action.state;
    //return state;
}