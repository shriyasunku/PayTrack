import React from 'react';
const Setting = () => {
    return <div className="title"> Settings</div>;
  };
  
  export default Setting;
  