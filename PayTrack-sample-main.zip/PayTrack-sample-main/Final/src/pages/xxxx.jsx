import React from 'react';
const Saved = () => {
    return <div className="title"> LogOut</div>;
  };
  
  export default Saved;