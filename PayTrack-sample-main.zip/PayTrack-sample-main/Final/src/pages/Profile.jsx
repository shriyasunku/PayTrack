import React from 'react';
const Users = () => {
    return <div className="title"> Profile</div>;
  };
  
  export default Users;
  