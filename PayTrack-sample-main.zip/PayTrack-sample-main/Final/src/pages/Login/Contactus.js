import React from 'react'
import '../../pages/Home.css'

export const Contactus = () => {
  return (
    <div className='about'>
      <>
      <p></p>
      <h1></h1>
      <p></p>
      </>
        {/* <br/><br/><br/>
        <center>
        <h1 style={{color: "white"}}>PayTrack</h1>
        <h4 style={{color: "white"}}> - You pay we track</h4><br/>
        <div className='mainBlock5'><h2>
            Paytrack is an expense tracker for the millennial people. 
            We live by the agenda of SSS which is Save, Spend and Secure. 
            It keeps an accurate record of our money inflow and outflow. 
            It entitles you to spend on what's important rather than what's desired. 
            Speechly is a toll for enhancing touch user interface with a voice modality. 
            In addition to touching and clicking, the end user can use the most natural way for interacting with application voice.  
            </h2></div>
        <div>
        </div>
        </center> */}
    </div>
  )
}
